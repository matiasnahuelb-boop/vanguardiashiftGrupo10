# VanguardiaShift 🏥

**Sistema web de gestión de turnos profesionales con arquitectura desacoplada**

[![Tests](https://github.com/vanguardiashift/backend/actions/workflows/test.yml/badge.svg)](https://github.com/vanguardiashift/backend/actions)
[![PHP](https://img.shields.io/badge/PHP-8.2-blue)](https://php.net)
[![Laravel](https://img.shields.io/badge/Laravel-11-red)](https://laravel.com)
[![Vue](https://img.shields.io/badge/Vue-3.4-green)](https://vuejs.org)
[![License](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)

---

## Tabla de Contenidos

- [Descripción](#descripción)
- [Arquitectura](#arquitectura)
- [Stack Tecnológico y Justificación](#stack-tecnológico)
- [Estructura del Proyecto](#estructura-del-proyecto)
- [Instalación y Puesta en Marcha](#instalación)
- [Endpoints de la API](#endpoints-de-la-api)
- [Testing](#testing)
- [Despliegue y CI/CD](#despliegue-y-cicd)
- [Seguridad](#seguridad)
- [Decisiones de Diseño](#decisiones-de-diseño)
- [Equipo](#equipo)

---

## Descripción

VanguardiaShift digitaliza la gestión de turnos en clínicas y consultorios profesionales. Reemplaza el sistema telefónico tradicional con una plataforma web que permite:

- **Clientes**: reservar turnos, ver disponibilidad en tiempo real, gestionar su historial.
- **Profesionales**: ver y gestionar su agenda, marcar turnos como completados o cancelados.
- **Administradores**: gestión completa del sistema.

### Problema que resuelve

| Problema | Solución implementada |
|---|---|
| Saturación telefónica matutina | Reservas online 24/7 sin intermediarios |
| Dobles reservas por error humano | `lockForUpdate()` previene condiciones de carrera |
| Falta de visibilidad del profesional | Agenda en tiempo real con filtro por fecha |
| Errores en carga manual de datos | Validación automática con mensajes en español |
| Sin historial de turnos cancelados | SoftDelete preserva todo el historial |

---

## Arquitectura

El sistema implementa **arquitectura desacoplada**: frontend y backend son proyectos independientes que se comunican exclusivamente vía API REST.

```
┌─────────────────────┐         HTTP / JSON          ┌──────────────────────┐
│   FRONTEND (Vue 3)  │  ←────────────────────────→  │  BACKEND (Laravel)   │
│                     │   Authorization: Bearer XXX   │                      │
│  BookingCalendar    │                               │  TurnoController     │
│  LoginView          │                               │  AuthController      │
│  AgendaView         │                               │  ProfesionalController│
│  Pinia + Router     │                               │  Sanctum + Eloquent  │
│                     │                               │         ↓            │
│  Vercel / Netlify   │                               │  MySQL / PostgreSQL  │
└─────────────────────┘                               └──────────────────────┘
```

### ¿Por qué desacoplado?

1. **Equipos independientes**: frontend y backend se desarrollan en paralelo sin bloquearse.
2. **Escalabilidad selectiva**: si el frontend recibe más tráfico, solo se escala esa capa.
3. **Reutilización**: la misma API puede alimentar una app móvil sin modificaciones.
4. **Flexibilidad tecnológica**: en el futuro se puede reemplazar Vue por otro framework sin tocar el backend.

---

## Stack Tecnológico

### Backend

| Tecnología | Versión | Justificación |
|---|---|---|
| **PHP** | 8.2 | Lenguaje maduro, rendimiento mejorado con JIT en 8.x |
| **Laravel** | 11 | Framework completo: ORM, autenticación, validación, testing integrados |
| **Laravel Sanctum** | 4.0 | Autenticación con tokens revocables, compatible con arquitectura desacoplada |
| **MySQL** | 8.0 | Motor relacional robusto para datos transaccionales |
| **PHPUnit** | 11 | Estándar de testing en PHP, integrado nativamente en Laravel |

### Frontend

| Tecnología | Versión | Justificación |
|---|---|---|
| **Vue.js** | 3.4 | Framework reactivo con Composition API, curva de aprendizaje accesible |
| **Vite** | 5.x | Bundler de última generación, HMR instantáneo en desarrollo |
| **Pinia** | 2.x | Store oficial de Vue 3, reemplaza Vuex con sintaxis más simple |
| **Vue Router** | 4.x | Sistema de rutas oficial para SPAs en Vue 3 |
| **Axios** | 1.6 | Cliente HTTP con interceptores, manejo de errores y cancelación de peticiones |
| **Tailwind CSS** | 3.4 | Utilidades CSS, responsive nativo, sin CSS custom |

### ¿Por qué Vue sobre React y Angular?

- Vue 3 tiene una curva de aprendizaje más accesible que React.
- Angular está diseñado para sistemas empresariales muy grandes — excesivo para este alcance.
- La Composition API de Vue 3 permite organizar el código por funcionalidad, no por tipo.
- Documentación oficial disponible en español.

### ¿Por qué Laravel sobre Node.js/Express?

- Laravel incluye todo lo necesario sin configuración adicional: Sanctum, Eloquent, validación, testing, migraciones.
- Node.js + Express requiere elegir e integrar manualmente cada una de esas librerías.
- Laravel tiene protecciones de seguridad integradas contra CSRF, XSS, SQL injection.

---

## Estructura del Proyecto

```
vanguardiashift/
├── backend/                          # Laravel 11 — API REST
│   ├── app/
│   │   ├── Http/
│   │   │   ├── Controllers/
│   │   │   │   ├── AuthController.php         # Login, register, logout
│   │   │   │   ├── TurnoController.php        # CRUD turnos + lockForUpdate
│   │   │   │   └── ProfesionalController.php  # Lista + disponibilidad
│   │   │   ├── Middleware/
│   │   │   │   └── CheckRole.php              # Verificación de roles
│   │   │   └── Requests/
│   │   │       └── StoreTurnoRequest.php      # Validación (SRP)
│   │   └── Models/
│   │       ├── User.php                       # Cliente, Profesional, Admin
│   │       └── Turno.php                      # Modelo con SoftDelete
│   ├── database/
│   │   ├── factories/
│   │   │   ├── UserFactory.php
│   │   │   └── TurnoFactory.php
│   │   ├── migrations/
│   │   │   ├── ..._create_users_table.php
│   │   │   └── ..._create_turnos_table.php
│   │   └── seeders/
│   │       └── DatabaseSeeder.php             # Datos de demo
│   ├── routes/
│   │   └── api.php                            # Rutas públicas y protegidas
│   ├── tests/
│   │   └── Feature/
│   │       └── TurnoTest.php                  # 6 tests de integración
│   ├── .env.example
│   ├── composer.json
│   └── phpunit.xml
│
├── frontend/                         # Vue 3 — SPA
│   └── src/
│       ├── components/
│       │   └── BookingCalendar.vue   # Flujo de reserva en 3 pasos
│       ├── views/
│       │   ├── LoginView.vue
│       │   ├── DashboardView.vue
│       │   ├── ReservarView.vue
│       │   └── AgendaView.vue
│       ├── router/
│       │   └── index.js              # Rutas + guardas de navegación
│       ├── stores/
│       │   └── auth.js               # Store Pinia de autenticación
│       └── services/
│           └── api.js                # Axios configurado con interceptores
│
├── .github/
│   └── workflows/
│       └── test.yml                  # Pipeline CI/CD
│
└── README.md                         # Este archivo
```

---

## Instalación

### Requisitos previos

- PHP >= 8.2 con extensiones: mbstring, pdo, pdo_mysql, pdo_sqlite, bcmath, xml
- Composer >= 2.x
- Node.js >= 18.x y npm >= 9.x
- MySQL >= 8.0 (o PostgreSQL, SQLite para desarrollo)

### Backend (Laravel)

```bash
# 1. Clonar el repositorio
git clone https://github.com/vanguardiashift/backend.git
cd backend

# 2. Instalar dependencias PHP
composer install

# 3. Configurar el entorno
cp .env.example .env
php artisan key:generate

# 4. Configurar la base de datos en .env
# DB_CONNECTION=mysql
# DB_DATABASE=vanguardiashift
# DB_USERNAME=tu_usuario
# DB_PASSWORD=tu_contraseña

# 5. Crear tablas y cargar datos de demo
php artisan migrate --seed

# 6. Iniciar el servidor de desarrollo
php artisan serve
# → API disponible en http://localhost:8000/api
```

### Frontend (Vue 3)

```bash
# 1. Clonar el repositorio
git clone https://github.com/vanguardiashift/frontend.git
cd frontend

# 2. Instalar dependencias JavaScript
npm install

# 3. Configurar la URL del backend
cp .env.example .env
# Editar VITE_API_URL=http://localhost:8000/api

# 4. Iniciar el servidor de desarrollo
npm run dev
# → Aplicación disponible en http://localhost:5173
```

### Credenciales de demostración

Después de ejecutar `php artisan migrate --seed`:

| Rol | Email | Contraseña |
|---|---|---|
| Admin | admin@vanguardiashift.com | password123 |
| Cliente (demo) | cliente@vanguardiashift.com | demo1234 |
| Profesional | v.perez@vanguardiashift.com | password123 |
| Profesional | m.garcia@vanguardiashift.com | password123 |

---

## Endpoints de la API

### Autenticación (públicos)

| Método | Ruta | Descripción |
|---|---|---|
| `POST` | `/api/auth/register` | Registro de nuevo usuario |
| `POST` | `/api/auth/login` | Inicio de sesión → devuelve token |
| `DELETE` | `/api/auth/logout` | Cerrar sesión (revoca el token) |

### Profesionales (requieren token)

| Método | Ruta | Acceso | Descripción |
|---|---|---|---|
| `GET` | `/api/profesionales` | Autenticado | Lista profesionales activos |
| `GET` | `/api/profesionales/{id}/disponibilidad?fecha=YYYY-MM-DD` | Autenticado | Horarios disponibles del día |

### Turnos (requieren token)

| Método | Ruta | Acceso | Descripción |
|---|---|---|---|
| `POST` | `/api/turnos` | Rol: cliente | Reservar turno (con lockForUpdate) |
| `GET` | `/api/turnos/profesional?fecha=YYYY-MM-DD` | Rol: profesional | Agenda del profesional |
| `PUT` | `/api/turnos/{id}/estado` | Rol: profesional | Cambiar estado (completado/cancelado) |

### Ejemplo de petición

```bash
# Login
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"cliente@vanguardiashift.com","password":"demo1234"}'

# Respuesta:
# { "token": "1|abc...", "usuario": { "id": 21, "rol": "cliente", ... } }

# Reservar turno (con el token obtenido)
curl -X POST http://localhost:8000/api/turnos \
  -H "Authorization: Bearer 1|abc..." \
  -H "Content-Type: application/json" \
  -d '{"profesional_id": 2, "fecha_hora": "2026-06-25 10:00:00", "motivo": "Control anual"}'
```

---

## Testing

### Ejecutar los tests

```bash
cd backend

# Ejecutar todos los tests
php artisan test

# Con detalle de cada test
php artisan test --verbose

# En paralelo (más rápido)
php artisan test --parallel
```

### Los 6 tests implementados

| Test | Qué verifica | Assertions clave |
|---|---|---|
| `test_cliente_autenticado_puede_reservar_turno` | Flujo feliz completo | HTTP 201, assertDatabaseHas |
| `test_no_se_puede_reservar_turno_con_horario_ocupado` | Concurrencia / lockForUpdate | HTTP 409, assertDatabaseCount(1) |
| `test_usuario_no_autenticado_no_puede_reservar_turno` | Middleware Sanctum | HTTP 401 |
| `test_validacion_rechaza_datos_invalidos` | StoreTurnoRequest | HTTP 422, assertJsonValidationErrors |
| `test_profesional_puede_marcar_turno_como_completado` | Cambio de estado | HTTP 200, assertDatabaseHas |
| `test_profesional_no_puede_modificar_turno_ajeno` | Autorización por recurso | HTTP 403 |

### Por qué SQLite en memoria para tests

Los tests verifican el comportamiento de la aplicación, no el motor de base de datos. SQLite `:memory:` permite que los 6 tests corran en aproximadamente **2 segundos** sin servidor externo. La base se crea y destruye automáticamente en cada test gracias al trait `RefreshDatabase`.

---

## Despliegue y CI/CD

### Pipeline (GitHub Actions)

Cada push a `main` dispara automáticamente el pipeline definido en `.github/workflows/test.yml`:

```
Push/PR → ubuntu-latest → composer install → configurar DB → migrate → php artisan test
```

Si todos los tests pasan ✅ → el código puede mergearse.
Si alguno falla ❌ → el merge queda bloqueado y el equipo recibe notificación.

### Deploy en producción

**Backend → Railway**
```bash
# 1. Conectar repositorio en railway.app
# 2. Configurar variables de entorno en el panel
# 3. Railway detecta composer.json y despliega automáticamente
```

**Frontend → Vercel**
```bash
# 1. Conectar repositorio en vercel.com
# 2. Configurar VITE_API_URL con la URL del backend en Railway
# 3. Vercel ejecuta npm run build y despliega automáticamente
```

---

## Seguridad

El sistema implementa 4 capas de protección:

### 1. Sanctum (Bearer Token)
- Cada petición protegida requiere `Authorization: Bearer {token}`
- Sin token válido → HTTP 401 automático
- Tokens almacenados hasheados en DB → revocación instantánea en logout
- **Ventaja sobre cookies de sesión**: funciona entre dominios distintos (CORS)

### 2. Middleware de Rol (CheckRole)
- `role:cliente` → solo puede reservar turnos
- `role:profesional` → solo puede gestionar su propia agenda
- Rol incorrecto → HTTP 403 Forbidden

### 3. StoreTurnoRequest (Validación)
- Se ejecuta antes del controlador
- Verifica que `profesional_id` exista en la DB
- Verifica que `fecha_hora` sea en el futuro
- Dato inválido → HTTP 422 con detalle en español

### 4. Autorización por Recurso
- En `cambiarEstado()`: verifica que `profesional_id === Auth::id()`
- No alcanza con tener rol 'profesional': hay que ser el dueño del turno
- Intento de modificar turno ajeno → HTTP 403

### Protecciones adicionales

- **`$fillable` en modelos**: previene Mass Assignment Attack
- **`SoftDelete`**: borrado lógico preserva trazabilidad
- **Hash::make()**: contraseñas con bcrypt, nunca en texto plano
- **Índices en DB**: `(profesional_id, fecha_hora)` optimiza la consulta de concurrencia

---

## Decisiones de Diseño

### lockForUpdate() — Prevención de Race Condition

Sin protección, dos usuarios pueden reservar el mismo horario simultáneamente:

```
Usuario A → consulta horario 10:00 → LIBRE
Usuario B → consulta horario 10:00 → LIBRE  (mismo instante)
Usuario A → crea turno → OK
Usuario B → crea turno → OK (ERROR: dos turnos en el mismo horario)
```

Con `lockForUpdate()` dentro de `DB::transaction()`:

```
Usuario A → bloquea fila del horario 10:00 → verifica → LIBRE → crea turno → libera bloqueo
Usuario B → espera el bloqueo → lee → OCUPADO → recibe HTTP 409 → elige otro horario
```

### Principios SOLID aplicados

| Principio | Aplicación |
|---|---|
| **S** — Responsabilidad Única | Cada clase tiene una sola tarea: rutas enrutan, Request valida, Controller decide, Model mapea |
| **O** — Abierto/Cerrado | Nuevas reglas de validación solo tocan `StoreTurnoRequest`, sin modificar el Controller |
| **L** — Sustitución de Liskov | Los modelos User y Turno extienden las clases base de Laravel sin alterar su comportamiento |
| **D** — Inversión de Dependencia | El Controller recibe `StoreTurnoRequest` como abstracción del formulario validado |

---

## Equipo

| Nombre | Rol en el proyecto |
|---|---|
| [Nombre 1] | Backend — Laravel, API REST, autenticación |
| [Nombre 2] | Frontend — Vue 3, componentes, UX |
| [Nombre 3] | Testing — PHPUnit, Feature Tests |
| [Nombre 4] | CI/CD — GitHub Actions, despliegue |
| [Nombre 5] | Arquitectura y documentación técnica |

---

## Materia

**Programación de Vanguardia** · Docente: Esteban Calcagno · Junio 2026

---

*Proyecto desarrollado como Trabajo Práctico Final para la materia Programación de Vanguardia.*
