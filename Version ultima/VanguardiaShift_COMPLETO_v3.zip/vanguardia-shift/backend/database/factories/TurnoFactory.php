<?php

/**
 * database/factories/TurnoFactory.php
 *
 * Fábrica de datos de prueba para el modelo Turno.
 *
 * @author  VanguardiaShift Team
 */

namespace Database\Factories;

use App\Models\Turno;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class TurnoFactory extends Factory
{
    protected $model = Turno::class;

    /**
     * Estado por defecto: turno reservado en el futuro.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        // Por defecto genera un turno en los próximos 30 días
        // entre las 9:00 y las 17:30, en franjas de 30 minutos
        $horasDisponibles = [];
        for ($h = 9; $h < 18; $h++) {
            $horasDisponibles[] = sprintf('%02d:00', $h);
            $horasDisponibles[] = sprintf('%02d:30', $h);
        }

        $fecha = fake()->dateTimeBetween('+1 day', '+30 days')->format('Y-m-d');
        $hora  = fake()->randomElement($horasDisponibles);

        return [
            'cliente_id'     => User::factory()->create()->id,
            'profesional_id' => User::factory()->profesional()->create()->id,
            'fecha_hora'     => $fecha . ' ' . $hora . ':00',
            'estado'         => 'reservado',
            'motivo'         => fake()->optional(0.7)->sentence(5), // 70% tiene motivo
            'notas_cliente'  => null,
        ];
    }

    /**
     * Estado "completado": turno en el pasado marcado como completado.
     *
     * @return static
     */
    public function completado(): static
    {
        return $this->state(fn (array $attributes) => [
            'fecha_hora'          => fake()->dateTimeBetween('-30 days', '-1 day')->format('Y-m-d H:i:s'),
            'estado'              => 'completado',
            'notas_profesional'   => fake()->paragraph(),
        ]);
    }

    /**
     * Estado "cancelado".
     *
     * @return static
     */
    public function cancelado(): static
    {
        return $this->state(fn (array $attributes) => [
            'estado' => 'cancelado',
        ]);
    }
}
