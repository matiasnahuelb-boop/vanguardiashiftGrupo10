<?php

/**
 * database/factories/UserFactory.php
 *
 * Fábrica de datos de prueba para el modelo User.
 *
 * Las Factories generan datos realistas y aleatorios para los tests
 * y los seeders. Faker es la librería que provee datos falsos
 * pero verosímiles (nombres, emails, fechas, etc.).
 *
 * Uso en tests:
 *   User::factory()->create()                    → cliente aleatorio
 *   User::factory()->profesional()->create()     → profesional aleatorio
 *   User::factory()->count(5)->create()          → 5 usuarios aleatorios
 *
 * @author  VanguardiaShift Team
 */

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

class UserFactory extends Factory
{
    /**
     * Modelo al que corresponde esta Factory.
     */
    protected $model = User::class;

    /**
     * Estado por defecto: usuario cliente con datos aleatorios.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name'              => fake()->name(),       // Nombre completo aleatorio
            'email'             => fake()->unique()->safeEmail(), // Email único y válido
            'email_verified_at' => now(),
            'password'          => Hash::make('password'), // Contraseña fija para tests
            'remember_token'    => null,
            'rol'               => 'cliente',
            'especialidad'      => null,
            'descripcion'       => null,
            'activo'            => true,
        ];
    }

    /**
     * Estado "profesional": genera un usuario con rol profesional
     * y datos específicos de un médico o especialista.
     *
     * Uso: User::factory()->profesional()->create()
     *
     * @return static
     */
    public function profesional(): static
    {
        $especialidades = [
            'Clínica Médica', 'Cardiología', 'Pediatría',
            'Psicología', 'Traumatología', 'Dermatología',
            'Neurología', 'Ginecología', 'Oftalmología',
        ];

        return $this->state(fn (array $attributes) => [
            'rol'          => 'profesional',
            'especialidad' => fake()->randomElement($especialidades),
            'descripcion'  => fake()->sentence(10),
            'activo'       => true,
        ]);
    }

    /**
     * Estado "admin": genera un usuario administrador.
     *
     * @return static
     */
    public function admin(): static
    {
        return $this->state(fn (array $attributes) => [
            'rol'  => 'admin',
            'name' => 'Administrador',
        ]);
    }
}
