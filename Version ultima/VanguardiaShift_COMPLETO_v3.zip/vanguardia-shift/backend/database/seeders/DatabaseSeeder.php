<?php

/**
 * database/seeders/DatabaseSeeder.php
 *
 * Seeder principal de VanguardiaShift.
 *
 * Los seeders poblan la base de datos con datos de demostración
 * realistas. Son fundamentales para:
 *  1. Mostrar el sistema funcionando en la presentación del TP
 *  2. Facilitar el desarrollo y las pruebas manuales
 *  3. Demostrar que el sistema maneja datos reales correctamente
 *
 * Ejecutar con: php artisan db:seed
 * O al migrar:  php artisan migrate --seed
 *
 * DATOS CREADOS:
 *  - 1 administrador
 *  - 6 profesionales con distintas especialidades
 *  - 20 clientes
 *  - ~60 turnos en distintos estados (pasados, presentes, futuros)
 *
 * @author  VanguardiaShift Team
 */

namespace Database\Seeders;

use App\Models\Turno;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Ejecuta el seeder principal.
     */
    public function run(): void
    {
        // ── ADMINISTRADOR ────────────────────────────────────────────────────
        User::create([
            'name'              => 'Administrador del Sistema',
            'email'             => 'admin@vanguardiashift.com',
            'password'          => Hash::make('password123'),
            'rol'               => 'admin',
            'activo'            => true,
            'email_verified_at' => now(),
        ]);

        // ── PROFESIONALES CON DATOS REALES ───────────────────────────────────
        $profesionales = [
            [
                'name'         => 'Dra. Valentina Pérez',
                'email'        => 'v.perez@vanguardiashift.com',
                'especialidad' => 'Clínica Médica',
                'descripcion'  => 'Especialista en medicina interna con 15 años de experiencia. Atención integral del adulto.',
            ],
            [
                'name'         => 'Dr. Martín García',
                'email'        => 'm.garcia@vanguardiashift.com',
                'especialidad' => 'Cardiología',
                'descripcion'  => 'Cardiólogo clínico e intervencionista. Miembro de la Sociedad Argentina de Cardiología.',
            ],
            [
                'name'         => 'Lic. Sofía Romero',
                'email'        => 's.romero@vanguardiashift.com',
                'especialidad' => 'Psicología',
                'descripcion'  => 'Psicóloga clínica con orientación cognitivo-conductual. Atención de adultos y adolescentes.',
            ],
            [
                'name'         => 'Dr. Lucas Fernández',
                'email'        => 'l.fernandez@vanguardiashift.com',
                'especialidad' => 'Traumatología',
                'descripcion'  => 'Traumatólogo y ortopedista. Especializado en patología deportiva.',
            ],
            [
                'name'         => 'Dra. Ana Gutiérrez',
                'email'        => 'a.gutierrez@vanguardiashift.com',
                'especialidad' => 'Pediatría',
                'descripcion'  => 'Pediatra con subespecialización en nutrición infantil.',
            ],
            [
                'name'         => 'Dr. Roberto Silva',
                'email'        => 'r.silva@vanguardiashift.com',
                'especialidad' => 'Dermatología',
                'descripcion'  => 'Dermatólogo clínico y estético. Diagnóstico y tratamiento de enfermedades de la piel.',
            ],
        ];

        $usuariosProfesionales = [];
        foreach ($profesionales as $data) {
            $usuariosProfesionales[] = User::create(array_merge($data, [
                'password'          => Hash::make('password123'),
                'rol'               => 'profesional',
                'activo'            => true,
                'email_verified_at' => now(),
            ]));
        }

        // ── CLIENTES ─────────────────────────────────────────────────────────
        $clientes = User::factory()->count(20)->create();

        // ── TURNOS CON DISTRIBUCIÓN REALISTA ─────────────────────────────────
        // Distribuimos turnos en 3 categorías para una demo convincente:
        // 1. Turnos completados en el pasado (historial)
        // 2. Turnos reservados para los próximos días (agenda activa)
        // 3. Un turno para el usuario demo "cliente@vanguardiashift.com"

        // Usuario demo para la presentación
        $clienteDemo = User::create([
            'name'              => 'Carlos Martínez (Demo)',
            'email'             => 'cliente@vanguardiashift.com',
            'password'          => Hash::make('demo1234'),
            'rol'               => 'cliente',
            'activo'            => true,
            'email_verified_at' => now(),
        ]);

        // Turnos del pasado (historial)
        foreach ($usuariosProfesionales as $profesional) {
            for ($i = 1; $i <= 5; $i++) {
                Turno::create([
                    'cliente_id'          => $clientes->random()->id,
                    'profesional_id'      => $profesional->id,
                    'fecha_hora'          => Carbon::now()->subDays(rand(1, 30))->setHour(rand(9, 17))->setMinute(rand(0, 1) * 30)->setSecond(0),
                    'estado'              => 'completado',
                    'motivo'              => fake()->sentence(5),
                    'notas_profesional'   => fake()->paragraph(),
                ]);
            }
        }

        // Turnos futuros (agenda activa)
        $horas = ['09:00', '09:30', '10:00', '10:30', '11:00', '14:00', '14:30', '15:00', '15:30', '16:00'];
        foreach ($usuariosProfesionales as $profesional) {
            $horasUsadas = [];
            for ($i = 1; $i <= 4; $i++) {
                $fecha = Carbon::now()->addDays(rand(1, 14))->format('Y-m-d');
                $hora  = $horas[array_rand($horas)];
                $key   = $profesional->id . '_' . $fecha . '_' . $hora;

                if (in_array($key, $horasUsadas)) continue; // evitar duplicados
                $horasUsadas[] = $key;

                Turno::create([
                    'cliente_id'     => $clientes->random()->id,
                    'profesional_id' => $profesional->id,
                    'fecha_hora'     => $fecha . ' ' . $hora . ':00',
                    'estado'         => 'reservado',
                    'motivo'         => fake()->optional()->sentence(4),
                ]);
            }
        }

        // Turno demo visible para la presentación
        Turno::create([
            'cliente_id'     => $clienteDemo->id,
            'profesional_id' => $usuariosProfesionales[0]->id, // Dra. Valentina Pérez
            'fecha_hora'     => Carbon::now()->addDays(3)->setHour(10)->setMinute(0)->setSecond(0),
            'estado'         => 'reservado',
            'motivo'         => 'Control anual de rutina',
        ]);

        $this->command->info('✅ Seeder completado. Datos de demo cargados:');
        $this->command->info('   Admin: admin@vanguardiashift.com / password123');
        $this->command->info('   Cliente demo: cliente@vanguardiashift.com / demo1234');
        $this->command->info('   Profesionales: [nombre]@vanguardiashift.com / password123');
    }
}
