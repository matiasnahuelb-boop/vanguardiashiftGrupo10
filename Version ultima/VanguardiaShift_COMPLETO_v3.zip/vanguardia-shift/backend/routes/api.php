<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProfesionalController;
use App\Http\Controllers\TurnoController;

/*
 * Rutas públicas — no requieren estar logueado
 */
Route::post('/auth/register', [AuthController::class, 'register']);
Route::post('/auth/login',    [AuthController::class, 'login']);

/*
 * Rutas protegidas — requieren Bearer Token válido de Sanctum
 * Si el token no viene o es inválido, Laravel responde con 401 automáticamente
 */
Route::middleware('auth:sanctum')->group(function () {

    Route::delete('/auth/logout', [AuthController::class, 'logout']);
    Route::get('/auth/me',        [AuthController::class, 'me']);

    // Profesionales y disponibilidad — cualquier usuario autenticado puede consultarlos
    Route::get('/profesionales', [ProfesionalController::class, 'index']);
    Route::get('/profesionales/{id}/disponibilidad', [ProfesionalController::class, 'disponibilidad']);

    // Turnos — con restricción por rol según la acción
    Route::post('/turnos', [TurnoController::class, 'store'])
        ->middleware('role:cliente');

    // Importante: esta ruta va ANTES de /turnos/{id} para que Laravel
    // no interprete "profesional" como un ID numérico
    Route::get('/turnos/profesional', [TurnoController::class, 'agendaProfesional'])
        ->middleware('role:profesional');

    Route::put('/turnos/{id}/estado', [TurnoController::class, 'cambiarEstado'])
        ->middleware('role:profesional');
});
