<?php

/**
 * app/Models/Turno.php
 *
 * Modelo Eloquent para la entidad "Turno" en VanguardiaShift.
 *
 * Eloquent ORM implementa el patrón Active Record: cada instancia de esta
 * clase representa una fila en la tabla 'turnos' y encapsula tanto los datos
 * como las operaciones de persistencia (save, update, delete).
 *
 * Relaciones definidas:
 *  - Un turno PERTENECE A un cliente (User con rol 'cliente').
 *  - Un turno PERTENECE A un profesional (User con rol 'profesional').
 *
 * @author VanguardiaShift Team
 * @version 1.0.0
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Turno extends Model
{
    // HasFactory: habilita el uso de TurnoFactory en tests y seeders.
    // SoftDeletes: en lugar de borrar el registro físicamente de la DB,
    //              setea la columna 'deleted_at' (borrado lógico).
    //              Esto preserva el historial de turnos para auditoría.
    use HasFactory, SoftDeletes;

    /**
     * Nombre de la tabla en la base de datos.
     * Por convención Laravel infiere 'turnos' del nombre 'Turno',
     * pero lo declaramos explícitamente para mayor claridad.
     *
     * @var string
     */
    protected $table = 'turnos';

    /**
     * Campos que se pueden asignar masivamente con create() o fill().
     *
     * SEGURIDAD: La propiedad $fillable protege contra "Mass Assignment Attacks".
     * Solo los campos listados aquí pueden ser seteados vía arrays.
     * Los campos como 'id', 'created_at', 'deleted_at' NO deben estar aquí.
     *
     * @var array<string>
     */
    protected $fillable = [
        'cliente_id',      // FK al usuario con rol cliente
        'profesional_id',  // FK al usuario con rol profesional
        'fecha_hora',      // Fecha y hora del turno (DATETIME en DB)
        'motivo',          // Motivo de la consulta (opcional)
        'estado',          // Estado del turno: reservado | confirmado | completado | cancelado
        'notas_cliente',   // Notas adicionales del cliente (opcional)
        'notas_profesional', // Notas del profesional post-consulta (opcional)
    ];

    /**
     * Casting de atributos: indica a Eloquent cómo convertir los valores
     * al leer desde la base de datos.
     *
     * Por ejemplo, 'fecha_hora' se convierte automáticamente a un objeto
     * Carbon (manejo avanzado de fechas en PHP) al acceder al atributo.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'fecha_hora'  => 'datetime',    // Convierte a instancia Carbon
        'created_at'  => 'datetime',
        'updated_at'  => 'datetime',
        'deleted_at'  => 'datetime',
    ];

    /**
     * Valores por defecto para los atributos del modelo.
     * Todo turno comienza en estado 'reservado' al ser creado.
     *
     * @var array<string, mixed>
     */
    protected $attributes = [
        'estado' => 'reservado',
    ];

    // =========================================================================
    // RELACIONES ELOQUENT (Patrón de Diseño: Relaciones de Dominio)
    // =========================================================================

    /**
     * Relación: Un turno pertenece a un cliente (usuario).
     *
     * BelongsTo es la relación "muchos a uno": muchos turnos pueden
     * pertenecer al mismo cliente.
     *
     * La clave foránea es 'cliente_id' en la tabla 'turnos'.
     * Laravel la infiere del nombre del método, pero la declaramos
     * explícitamente para mayor claridad y mantenibilidad.
     *
     * Uso: $turno->cliente  → devuelve el objeto User del cliente.
     *
     * @return BelongsTo
     */
    public function cliente(): BelongsTo
    {
        // belongsTo(ModeloRelacionado, claveForanea, clavePrimaria)
        return $this->belongsTo(User::class, 'cliente_id', 'id');
    }

    /**
     * Relación: Un turno pertenece a un profesional (usuario).
     *
     * Aunque tanto 'cliente' como 'profesional' referencian la misma
     * tabla 'users', representan roles distintos del sistema.
     * Usamos la misma clase User con diferentes claves foráneas.
     *
     * Uso: $turno->profesional  → devuelve el objeto User del profesional.
     *
     * @return BelongsTo
     */
    public function profesional(): BelongsTo
    {
        return $this->belongsTo(User::class, 'profesional_id', 'id');
    }

    // =========================================================================
    // SCOPES (Consultas reutilizables - Patrón Query Scope)
    // =========================================================================

    /**
     * Scope: filtra turnos por estado.
     *
     * Los Query Scopes permiten encadenar condiciones de consulta de forma
     * legible y reutilizable. Ejemplo de uso:
     *   Turno::reservados()->get()
     *   Turno::where('profesional_id', 5)->reservados()->get()
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeReservados($query)
    {
        return $query->where('estado', 'reservado');
    }

    /**
     * Scope: filtra turnos futuros (a partir de ahora).
     * Útil para mostrar la agenda próxima de un profesional.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeFuturos($query)
    {
        return $query->where('fecha_hora', '>=', now());
    }

    /**
     * Scope: filtra turnos de una fecha específica.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $fecha  Formato: YYYY-MM-DD
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeDelDia($query, string $fecha)
    {
        return $query->whereDate('fecha_hora', $fecha);
    }
}
