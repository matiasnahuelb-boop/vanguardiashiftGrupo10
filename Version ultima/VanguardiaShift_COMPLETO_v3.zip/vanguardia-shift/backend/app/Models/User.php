<?php

/**
 * app/Models/User.php
 *
 * Modelo de usuario para VanguardiaShift.
 *
 * Un único modelo User representa todos los tipos de usuario del sistema
 * (cliente, profesional, admin) diferenciados por el campo 'rol'.
 * Esta decisión evita duplicar la lógica de autenticación en múltiples tablas.
 *
 * Traits incluidos:
 *  - HasApiTokens:    habilita la autenticación con Sanctum (tokens Bearer)
 *  - HasFactory:      permite generar datos de prueba con UserFactory
 *  - Notifiable:      permite enviar notificaciones por email u otros canales
 *  - SoftDeletes:     borrado lógico — el usuario no se elimina físicamente
 *
 * @author  VanguardiaShift Team
 * @version 1.0.0
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    /**
     * Campos asignables masivamente.
     *
     * El campo 'rol' está incluido para que el seeder pueda
     * crear usuarios con distintos roles. En el AuthController,
     * el registro siempre asigna 'cliente' explícitamente,
     * por lo que no hay riesgo de Mass Assignment Attack.
     *
     * @var array<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'rol',           // 'cliente' | 'profesional' | 'admin'
        'especialidad',  // Solo para profesionales (ej: "Cardiología")
        'descripcion',   // Bio breve del profesional
        'activo',        // Para desactivar profesionales sin borrarlos
    ];

    /**
     * Campos ocultos en las respuestas JSON.
     *
     * La contraseña y los tokens de remember nunca deben
     * exponerse en las respuestas de la API.
     *
     * @var array<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Casting de atributos: conversión automática de tipos al leer de la DB.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password'          => 'hashed',  // Laravel hashea automáticamente al asignar
            'activo'            => 'boolean',
        ];
    }

    // =========================================================================
    // RELACIONES ELOQUENT
    // =========================================================================

    /**
     * Un usuario cliente puede tener muchos turnos reservados.
     *
     * Uso: $user->turnosComoCliente
     *
     * @return HasMany
     */
    public function turnosComoCliente(): HasMany
    {
        return $this->hasMany(Turno::class, 'cliente_id');
    }

    /**
     * Un usuario profesional puede tener muchos turnos en su agenda.
     *
     * Uso: $user->turnosComoP rofesional
     *
     * @return HasMany
     */
    public function turnosComoProfesional(): HasMany
    {
        return $this->hasMany(Turno::class, 'profesional_id');
    }

    // =========================================================================
    // HELPERS DE ROL
    // =========================================================================

    /**
     * Verifica si el usuario tiene un rol específico.
     * Más legible que comparar el string directamente.
     *
     * Uso: if ($user->esRol('admin')) { ... }
     *
     * @param  string  $rol
     * @return bool
     */
    public function esRol(string $rol): bool
    {
        return $this->rol === $rol;
    }

    /**
     * @return bool
     */
    public function esCliente(): bool
    {
        return $this->rol === 'cliente';
    }

    /**
     * @return bool
     */
    public function esProfesional(): bool
    {
        return $this->rol === 'profesional';
    }

    /**
     * @return bool
     */
    public function esAdmin(): bool
    {
        return $this->rol === 'admin';
    }
}
