<?php

/**
 * app/Http/Controllers/ProfesionalController.php
 *
 * Controlador para gestión de profesionales y su disponibilidad.
 *
 * Responsabilidades:
 *  - Listar profesionales activos del sistema.
 *  - Calcular la disponibilidad horaria de un profesional
 *    para una fecha dada, descontando los turnos ya reservados.
 *
 * @author  VanguardiaShift Team
 * @version 1.0.0
 */

namespace App\Http\Controllers;

use App\Models\Turno;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProfesionalController extends Controller
{
    /**
     * Horario laboral estándar: 9:00 a 18:00, franjas de 30 minutos.
     * Centralizar esta configuración facilita cambiarla en el futuro
     * sin tocar la lógica de cálculo.
     */
    private const HORA_INICIO  = 9;   // 9:00 AM
    private const HORA_FIN     = 18;  // 6:00 PM
    private const DURACION_MIN = 30;  // duración de cada turno en minutos

    // =========================================================================
    // LISTADO DE PROFESIONALES
    // =========================================================================

    /**
     * Devuelve todos los profesionales activos del sistema.
     *
     * Solo retorna usuarios con rol 'profesional' y estado activo.
     * No expone datos sensibles (contraseña, tokens, etc.).
     *
     * @return JsonResponse
     */
    public function index(): JsonResponse
    {
        // select() limita los campos devueltos por seguridad
        // y rendimiento: no enviamos más datos de los necesarios
        $profesionales = User::where('rol', 'profesional')
            ->where('activo', true)
            ->select(['id', 'name', 'email', 'especialidad', 'descripcion'])
            ->orderBy('name')
            ->get();

        return response()->json([
            'mensaje' => 'Profesionales obtenidos correctamente.',
            'total'   => $profesionales->count(),
            'data'    => $profesionales,
        ], 200);
    }

    // =========================================================================
    // DISPONIBILIDAD
    // =========================================================================

    /**
     * Calcula los horarios disponibles de un profesional para una fecha.
     *
     * Algoritmo:
     * 1. Generar todos los slots posibles del día (9:00 a 17:30).
     * 2. Consultar turnos ya reservados en ese día.
     * 3. Marcar como no disponibles los slots ocupados.
     *
     * Esto permite que el frontend muestre cada franja horaria
     * con su estado real (libre / ocupado) sin hacer múltiples
     * consultas a la API.
     *
     * @param  Request  $request
     * @param  int      $id       ID del profesional
     * @return JsonResponse
     */
    public function disponibilidad(Request $request, int $id): JsonResponse
    {
        // Validar que el parámetro de fecha sea correcto
        $request->validate([
            'fecha' => ['required', 'date_format:Y-m-d', 'after_or_equal:today'],
        ], [
            'fecha.required'        => 'La fecha es obligatoria.',
            'fecha.date_format'     => 'El formato de fecha debe ser YYYY-MM-DD.',
            'fecha.after_or_equal'  => 'No se puede consultar disponibilidad de fechas pasadas.',
        ]);

        // Verificar que el profesional exista y esté activo
        $profesional = User::where('id', $id)
            ->where('rol', 'profesional')
            ->where('activo', true)
            ->firstOrFail();
        // firstOrFail() devuelve HTTP 404 automáticamente si no existe

        $fecha = $request->fecha;

        // --- Generar todos los slots del día ---
        $slots = $this->generarSlots($fecha);

        // --- Obtener turnos ya reservados en esa fecha ---
        // Recuperamos solo la hora del turno para comparar con cada slot
        $turnosReservados = Turno::where('profesional_id', $id)
            ->whereDate('fecha_hora', $fecha)
            ->whereIn('estado', ['reservado', 'confirmado'])
            ->pluck('fecha_hora') // devuelve solo la columna fecha_hora
            ->map(fn($dt) => Carbon::parse($dt)->format('H:i')) // extrae solo la hora
            ->toArray();

        // --- Marcar disponibilidad de cada slot ---
        $slotsConEstado = array_map(function ($slot) use ($turnosReservados, $fecha) {
            $estaOcupado = in_array($slot, $turnosReservados);
            return [
                'hora'         => $slot,
                'fecha_hora'   => $fecha . ' ' . $slot . ':00',
                'disponible'   => !$estaOcupado,
                'estado'       => $estaOcupado ? 'ocupado' : 'libre',
            ];
        }, $slots);

        return response()->json([
            'profesional' => [
                'id'   => $profesional->id,
                'name' => $profesional->name,
            ],
            'fecha'           => $fecha,
            'total_slots'     => count($slotsConEstado),
            'slots_libres'    => count(array_filter($slotsConEstado, fn($s) => $s['disponible'])),
            'slots_ocupados'  => count(array_filter($slotsConEstado, fn($s) => !$s['disponible'])),
            'horarios'        => $slotsConEstado,
        ], 200);
    }

    // =========================================================================
    // MÉTODO PRIVADO: GENERADOR DE SLOTS
    // =========================================================================

    /**
     * Genera todos los horarios posibles de un día laboral.
     *
     * @param  string  $fecha  Formato: YYYY-MM-DD
     * @return array           Array de strings con formato HH:MM
     */
    private function generarSlots(string $fecha): array
    {
        $slots   = [];
        $inicio  = Carbon::parse($fecha)->setHour(self::HORA_INICIO)->setMinute(0);
        $fin     = Carbon::parse($fecha)->setHour(self::HORA_FIN)->setMinute(0);

        // Avanzamos de a DURACION_MIN minutos hasta llegar al fin
        while ($inicio->lt($fin)) {
            $slots[] = $inicio->format('H:i');
            $inicio->addMinutes(self::DURACION_MIN);
        }

        return $slots;
    }
}
