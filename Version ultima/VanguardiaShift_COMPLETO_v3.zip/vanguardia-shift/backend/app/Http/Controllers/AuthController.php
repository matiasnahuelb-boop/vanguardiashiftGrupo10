<?php

/**
 * app/Http/Controllers/AuthController.php
 *
 * Controlador de autenticación para VanguardiaShift.
 *
 * Gestiona el ciclo completo de identidad del usuario:
 * registro, inicio de sesión y cierre de sesión seguro.
 *
 * Principios aplicados:
 *  - SRP: este controlador solo maneja autenticación,
 *    no lógica de negocio de turnos.
 *  - Seguridad: contraseñas hasheadas con bcrypt,
 *    tokens Sanctum revocables, validación estricta.
 *
 * @author  VanguardiaShift Team
 * @version 1.0.0
 */

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    // =========================================================================
    // REGISTRO
    // =========================================================================

    /**
     * Registra un nuevo usuario en el sistema.
     *
     * El rol por defecto es 'cliente'. Solo el administrador
     * puede asignar rol 'profesional' desde el panel de admin.
     * Esto previene que alguien se registre como profesional
     * manipulando el payload de la petición.
     *
     * @param  Request  $request
     * @return JsonResponse  HTTP 201 con token de acceso
     */
    public function register(Request $request): JsonResponse
    {
        // Validación estricta de los datos de registro
        $validated = $request->validate([
            'name'     => ['required', 'string', 'max:255'],
            'email'    => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'confirmed', Password::min(8)],
            // 'confirmed' verifica que exista el campo 'password_confirmation'
            // con el mismo valor — protege contra errores de tipeo
        ], [
            'email.unique'    => 'Este correo electrónico ya está registrado.',
            'password.min'    => 'La contraseña debe tener al menos 8 caracteres.',
            'password.confirmed' => 'Las contraseñas no coinciden.',
        ]);

        // Crear el usuario con rol 'cliente' por defecto
        $user = User::create([
            'name'     => $validated['name'],
            'email'    => $validated['email'],
            // Hash::make() aplica bcrypt con salt automático.
            // Nunca se guarda la contraseña en texto plano.
            'password' => Hash::make($validated['password']),
            'rol'      => 'cliente',
        ]);

        // Generar token de acceso Sanctum
        // El nombre del token identifica el dispositivo o sesión
        $token = $user->createToken('auth-token')->plainTextToken;

        return response()->json([
            'mensaje' => 'Registro exitoso. Bienvenido a VanguardiaShift.',
            'token'   => $token,
            'usuario' => [
                'id'    => $user->id,
                'name'  => $user->name,
                'email' => $user->email,
                'rol'   => $user->rol,
            ],
        ], 201);
    }

    // =========================================================================
    // INICIO DE SESIÓN
    // =========================================================================

    /**
     * Autentica un usuario y devuelve un token de acceso.
     *
     * El token es un string opaco (no JWT) que se almacena
     * hasheado en la tabla personal_access_tokens.
     * Cada login genera un nuevo token; los anteriores
     * siguen válidos hasta que se revoquen explícitamente.
     *
     * @param  Request  $request
     * @return JsonResponse  HTTP 200 con token | HTTP 401 si credenciales inválidas
     */
    public function login(Request $request): JsonResponse
    {
        $request->validate([
            'email'    => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        // Auth::attempt() verifica email + password hasheado
        // y establece la sesión internamente para este request
        if (!Auth::attempt($request->only('email', 'password'))) {
            return response()->json([
                'mensaje' => 'Credenciales incorrectas. Verificá tu email y contraseña.',
            ], 401);
        }

        $user  = Auth::user();
        $token = $user->createToken('auth-token')->plainTextToken;

        return response()->json([
            'mensaje' => 'Inicio de sesión exitoso.',
            'token'   => $token,
            'usuario' => [
                'id'    => $user->id,
                'name'  => $user->name,
                'email' => $user->email,
                'rol'   => $user->rol,
            ],
        ], 200);
    }

    // =========================================================================
    // CIERRE DE SESIÓN
    // =========================================================================

    /**
     * Revoca el token de acceso actual del usuario.
     *
     * La revocación es inmediata: el token se elimina de la
     * tabla personal_access_tokens. Cualquier petición posterior
     * con ese token recibirá HTTP 401 automáticamente.
     *
     * Esta es la ventaja de Sanctum sobre JWT: con JWT no se
     * puede invalidar un token antes de que expire.
     *
     * @param  Request  $request
     * @return JsonResponse  HTTP 200 confirmando el logout
     */
    public function logout(Request $request): JsonResponse
    {
        // currentAccessToken() devuelve el token que autenticó
        // esta petición específica. delete() lo elimina de la DB.
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'mensaje' => 'Sesión cerrada correctamente.',
        ], 200);
    }

    /**
     * Devuelve los datos del usuario autenticado actualmente.
     * Útil para que el frontend verifique la sesión al recargar.
     *
     * @param  Request  $request
     * @return JsonResponse
     */
    public function me(Request $request): JsonResponse
    {
        return response()->json([
            'usuario' => $request->user(),
        ], 200);
    }
}
