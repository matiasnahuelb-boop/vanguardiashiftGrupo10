<?php

/**
 * app/Http/Requests/StoreTurnoRequest.php
 *
 * Form Request para la validación de la reserva de un turno.
 *
 * Al separar las reglas de validación del controlador (SRP), el controlador
 * queda limpio y este archivo puede reutilizarse o extenderse fácilmente.
 *
 * Laravel ejecuta authorize() y rules() ANTES de que el controlador
 * reciba el request, garantizando que los datos sean válidos en todo momento.
 *
 * @author VanguardiaShift Team
 * @version 1.0.0
 */

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreTurnoRequest extends FormRequest
{
    /**
     * Determina si el usuario autenticado está autorizado a realizar esta petición.
     *
     * La autorización de ROL ya fue manejada por el middleware 'role:cliente'
     * en las rutas, por lo que aquí simplemente verificamos que el usuario
     * esté autenticado (lo cual ya garantiza Sanctum).
     *
     * @return bool  true = la petición está autorizada.
     */
    public function authorize(): bool
    {
        // Si llegamos hasta aquí, Sanctum ya validó el token. Autorizado.
        return true;
    }

    /**
     * Define las reglas de validación para los campos del request.
     *
     * Reglas aplicadas:
     *  - profesional_id: debe existir en la tabla users como profesional activo.
     *  - fecha_hora: debe ser una fecha futura (after:now), no se pueden reservar
     *    turnos en el pasado.
     *  - motivo: texto libre opcional, máximo 500 caracteres.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            // Valida que el profesional exista en la DB y sea del rol correcto
            'profesional_id' => [
                'required',
                'integer',
                // exists:tabla,columna - Laravel verifica en la DB automáticamente
                'exists:users,id',
            ],

            // Fecha y hora del turno: formato ISO 8601, debe ser una fecha futura
            'fecha_hora' => [
                'required',
                'date',         // Valida que sea una fecha/hora válida
                'after:now',    // No permite reservar en el pasado
            ],

            // Motivo de la consulta (opcional)
            'motivo' => [
                'nullable',
                'string',
                'max:500', // Limitamos para evitar datos excesivos
            ],

            // Notas adicionales del cliente (opcional)
            'notas_cliente' => [
                'nullable',
                'string',
                'max:1000',
            ],
        ];
    }

    /**
     * Mensajes de error personalizados en español.
     *
     * Por defecto Laravel genera mensajes en inglés. Los personalizamos
     * para mejorar la experiencia del usuario final.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'profesional_id.required' => 'Debes seleccionar un profesional.',
            'profesional_id.exists'   => 'El profesional seleccionado no existe.',
            'fecha_hora.required'     => 'La fecha y hora del turno son obligatorias.',
            'fecha_hora.date'         => 'El formato de fecha y hora no es válido.',
            'fecha_hora.after'        => 'No puedes reservar un turno en el pasado.',
            'motivo.max'              => 'El motivo no puede superar los 500 caracteres.',
        ];
    }
}
