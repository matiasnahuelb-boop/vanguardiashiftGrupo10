<?php

/**
 * app/Http/Middleware/CheckRole.php
 *
 * Middleware de verificación de roles para VanguardiaShift.
 *
 * Este middleware implementa la segunda capa de seguridad del sistema
 * (la primera es Sanctum que verifica el token, la segunda es esta
 * que verifica el rol del usuario autenticado).
 *
 * Principio de mínimo privilegio: un cliente no puede acceder a
 * endpoints de profesionales y viceversa, aunque ambos tengan
 * tokens válidos.
 *
 * Registro: en bootstrap/app.php agregar:
 *   ->withMiddleware(function (Middleware $middleware) {
 *       $middleware->alias(['role' => \App\Http\Middleware\CheckRole::class]);
 *   })
 *
 * Uso en rutas: Route::middleware('role:profesional')
 *
 * @author  VanguardiaShift Team
 * @version 1.0.0
 */

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    /**
     * Verifica que el usuario autenticado tenga el rol requerido.
     *
     * Si el rol no coincide, devuelve HTTP 403 Forbidden.
     * HTTP 403 significa: "te identifiqué, pero no tenés permiso
     * para este recurso" (a diferencia de 401 = no identificado).
     *
     * @param  Request  $request
     * @param  Closure  $next    Pasa la petición al siguiente middleware o controlador
     * @param  string   ...$roles  Uno o más roles permitidos (ej: 'cliente', 'admin')
     * @return Response
     */
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $usuario = $request->user();

        // Verificar que el usuario esté autenticado
        // (aunque Sanctum ya debería haberlo garantizado)
        if (!$usuario) {
            return response()->json([
                'mensaje' => 'No autenticado.',
            ], 401);
        }

        // Verificar si el rol del usuario está entre los roles permitidos
        // in_array() verifica si $usuario->rol existe en el array $roles
        if (!in_array($usuario->rol, $roles)) {
            return response()->json([
                'mensaje' => "Acceso denegado. Se requiere uno de los siguientes roles: " . implode(', ', $roles) . ".",
                'tu_rol'  => $usuario->rol,
            ], 403);
        }

        // El rol es válido: pasar la petición al siguiente paso
        return $next($request);
    }
}
